# Troll Page Scream

This project is a troll screamer web page created using HTML, CSS, and JavaScript.
 
## Link 👉 https://Pablo-Restrepo.github.io/Troll-Page-Scream/

<p align="center">
  <img src="docs/image1.png"">
</p>

<p align="center">
  <img src="docs/image2.png"">
</p>

## License
This project is licensed under the GNU General Public License v3.0. See the `LICENSE` file for more details.
